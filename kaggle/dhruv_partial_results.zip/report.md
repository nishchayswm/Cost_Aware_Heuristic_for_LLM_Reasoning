# Local reasoning benchmark

Complete all-method blocks: 30. Saved method results: 184.

Accuracy and costs below use only completed all-method blocks. Errors count as incorrect; inspect status and unknown-cost failures.

| Method | Original correct / N | Original accuracy | Reviewed correct / N | Reviewed accuracy | Calls | Input tokens | Output tokens | Seconds |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Proposed: five-factor best-first | 27/30 | 90.0% | 27/30 | 90.0% | 8.1 | 3523.333 | 562.367 | 21.627 |
| Single-path CoT (calculator-assisted) | 27/30 | 90.0% | 27/30 | 90.0% | 1.067 | 316.967 | 101.1 | 3.787 |
| Self-Consistency | 27/30 | 90.0% | 27/30 | 90.0% | 6.233 | 1842.633 | 592.933 | 21.87 |
| ToT: bounded breadth/beam search | 27/30 | 90.0% | 27/30 | 90.0% | 9 | 3990.033 | 620.367 | 23.937 |
| Self-evaluation stochastic beam (prompted-score adaptation) | 27/30 | 90.0% | 27/30 | 90.0% | 8.767 | 3816.633 | 608.167 | 23.368 |
| Quality-only best-first (controlled baseline) | 27/30 | 90.0% | 27/30 | 90.0% | 8.733 | 3885.8 | 607.333 | 23.407 |

Original metrics retain dataset labels. Reviewed metrics use only the frozen evaluator-only label corrections saved with this run. Legacy runs without reviewed fields retain their original scores; no retrospective correction is applied.
These are calculator-assisted local adaptations, not reproductions of published SOTA scores. Self-evaluation beam uses prompted scores, not the original probability-based objective.
Five-factor best-first ranks intermediate states using quality, uncalibrated success confidence, depth, estimated additional token cost and lexical diversity. Weights are provisional, not learned.
Wilson intervals are descriptive for single-seed runs; use question-cluster bootstrap differences for repeated seeds.
Inference seconds include recorded request wall time. Warmup is excluded and separately recorded. Timing depends on caching and background load.
A 100-question pilot cannot by itself establish non-inferiority or SOTA. Do not tune using these test results.
