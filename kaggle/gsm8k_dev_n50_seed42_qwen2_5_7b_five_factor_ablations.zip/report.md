# Five-factor ranking ablations

36 complete six-variant question blocks; 216 saved method results.

| Variant | Correct / N | Accuracy | Mean calls | Mean tokens | Unknown-cost rows |
|---|---:|---:|---:|---:|---:|
| Main: five-factor priority | 32/36 | 88.9% | 9.42 | 4909.72 | 0 |
| Without quality | 31/36 | 86.1% | 9.08 | 4659 | 0 |
| Without success | 31/36 | 86.1% | 9.83 | 5138.92 | 0 |
| Without depth | 32/36 | 88.9% | 9.42 | 4943.25 | 0 |
| Without cost | 33/36 | 91.7% | 9.42 | 4899.19 | 0 |
| Without diversity | 32/36 | 88.9% | 9.42 | 4955.36 | 0 |

Only complete paired blocks enter the summary and comparisons.
Each ablation removes one feature from priority ranking and renormalizes the other weights.
Removing Q or P also removes its depth/diversity interaction in priority.
The judge still computes Q/P and the common final answer selector still uses both.
All variants use the same seed stream for identical prompts; later branches can diverge.
Failed HTTP calls have unknown token cost; resumed rows flag it and totals are lower bounds.
A small development run is diagnostic, not evidence of a general improvement.
