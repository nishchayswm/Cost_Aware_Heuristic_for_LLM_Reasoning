# Mini crosswords: 10 puzzles, two search policies

## Run on five Kaggle sessions now

Use the five notebooks in `parallel/`, one different notebook per session:

| Notebook | Global puzzle indices | Methods |
|---|---|---|
| `Crosswords10_Batch01_of_05.ipynb` | 1–2 | Both |
| `Crosswords10_Batch02_of_05.ipynb` | 3–4 | Both |
| `Crosswords10_Batch03_of_05.ipynb` | 5–6 | Both |
| `Crosswords10_Batch04_of_05.ipynb` | 7–8 | Both |
| `Crosswords10_Batch05_of_05.ipynb` | 9–10 | Both |

Each notebook embeds the same frozen dataset and exact model revision. No live
dataset sampling occurs on Kaggle. The assigned pairs cover the first ten puzzles
of the established seed-2026 pool exactly once. Each method/puzzle has 30,000 total
tokens, 60 model calls including retries, and 30 expansions. The trial seed is 42.
The full comparison is 20 method runs, four per notebook. Preflight calls are
separately saved and are additional setup cost in each session.

Enable GPU and Internet, run installation, restart the kernel, then continue in
order. After preflight passes, the run cell starts its assigned batch by default.
The final export cell discovers saved runs even after a kernel restart. Download
each uniquely named ZIP or the individually named result JSONL and manifest JSON.
Use the export cell for partial checkpoints too. It includes the project source,
dataset provenance, raw calls and saved records. An interrupted inference can
still have unknown cost; the existing trial safeguards apply.

Extract each ZIP once into a downloads folder, then merge locally:

```powershell
python crosswords_kaggle/merge_crossword_batches.py downloads --output crossword_merged
```

The merger requires all five complete batches, identical dataset/model/config/
package versions/code/seed, and both methods for every puzzle. It rejects duplicate
exports and mixed experiments. It writes merged JSONL, paired tables and summaries.
Each batch's GPU and runtime are preserved in the manifest; wall-time comparisons
across different GPU types are not controlled. Keep per-method token/call results.
The new batch notebooks have offline tests; live Kaggle validation is pending.

## Smaller run with more search (v3)

Upload `Crosswords10_Heuristic_vs_ToT_Kaggle.ipynb`. The default is 10 puzzles
and two methods (20 solver runs). Each method gets at most 60 expansions,
160 calls and 120,000 total input/output tokens per puzzle. Depth remains 20,
branching 3 and frontier 60. These are exploratory settings, not tuned optima.
The larger call/token budgets allow more expansions; a run can still reach
another limit or exhaust its frontier before 60 expansions.

`PUZZLE_LIMIT=10` selects the first ten entries of the same frozen 50-puzzle
pool. Both methods receive that identical subset. Change the limit from 1 to 50
in the dataset cell before starting; selection never depends on answers or scores.
The full pool remains saved for provenance. `selected_questions.json` records
the selected inputs, while each run manifest records the exact IDs and count.

Run setup, restart the kernel after dependency installation, then continue through
the preflight check. Set `RUN_BENCHMARK=True` once preflight passes.
The new project path is `/kaggle/working/crosswords10_schema_v3`; default results
are in `results/schema_v3_n10_exp60_seed42/`. Existing source datasets and model
pins are copied from older project folders when available. The export filename
includes the selected count and expansion limit. Earlier notebooks remain available.

## Structured output repair (v2)

Use the regenerated notebook and restart the kernel after installing dependencies.
The v2 backend uses `lm-format-enforcer==0.11.3` to constrain JSON during decoding:
move slots follow h1-h5/v1-v5 and each word contains exactly five English letters.
Completed JSON cannot have trailing markdown or a fabricated conversation.
Local validation also checks numeric scores and complete, unique evaluation IDs.
Truncated or invalid responses have up to two retries within the same call/token
budgets; exhausted retries report `invalid_model_response` explicitly.

Run the new preflight cell before setting `RUN_BENCHMARK=True`. Its model calls
and costs are saved separately from the measured experiment.
Output constraints enforce format and length, not correct answers.
This repair has offline validation; a live Kaggle GPU run is still required.

Upload the 10-puzzle notebook named above to Kaggle. It embeds all necessary source and offline tests. Enable GPU and Internet, run setup cells, then set `RUN_BENCHMARK=True` in the run cell. No Ollama or paid API is needed. Default model: Qwen/Qwen2.5-7B-Instruct, 4-bit NF4 on one GPU. The notebook has not been executed on Kaggle by its authoring agent.

Exactly 50 unique grids are selected without replacement from the original ToT `mini0505.json`, using selection seed 2026. The upstream commit, data hash, selected IDs and source license are saved. This is a custom random split, not ToT's published crossword test subset. No evaluation puzzle is used for tuning. Answer keys are passed to the scoring function only after search returns; the policy receives only the ten clues. Dataset availability does not establish absence from model pretraining.

## Methods and shared controls

- `tot_dfs`: ToT-style depth-first search, confidence-ordered children, model feasibility pruning and backtracking through retained alternatives. This is a local-model adaptation, not an exact reproduction of ToT's published prompts/evaluation protocol.
- `heuristic_bestfirst`: same candidates and evaluations, with best-first selection by the five-factor heuristic.

Each state holds ten explicit word assignments. Revising a word clears conflicting crossing assignments. Both methods use this same revision rule, duplicate-state filter, batch evaluation, candidate generation, shared feasibility threshold and final-output ranking. Full grids can still be revised; filling the grid is not a correctness certificate. The final grid maximizes `coverage * Q` among evaluated candidates, with coverage, P and smaller depth as tiebreakers. Ground truth never chooses the winning state or triggers early stopping.

Default limits per method and puzzle: 120,000 total input+output tokens, 160 calls, 60 expansions, depth 20, branching 3 and frontier 60. Exact tokenizer counts reserve the full completion allowance before each call. A limited budget may end with unused tokens. Both generation and batch judging are charged. Invalid JSON consumes its real cost and retries are counted.

## Heuristic

`H = .35 Q + .30 P - .05 D - .15 C + .15 V`

- Q: model-rated average plausibility of completely filled clue slots, including words implied by crossings.
- P: model-rated feasibility of satisfying the whole crossword. This is not a calibrated probability.
- D: normalized action depth, multiplied by `(1-P)`; revisions count as actions.
- C: estimated future-work proxy: unassigned-slot fraction times two average-cost calls, divided by total token budget, clipped to [0,1]. It is not a trained cost forecast. Averages include prompt and completion tokens.
- V: minimum normalized assignment distance from another retained frontier state, multiplied by `sqrt(Q*P)`. Singleton frontier diversity is zero.

Weights are carried over as provisional weights; no crossword weight fitting is performed. Features are task adaptations, not a claim of a learned cross-task policy. The notebook computes per-puzzle paired differences in word accuracy, with a bootstrap interval; ten puzzles provide diagnostic evidence only.

## Output and resume

Both methods run on each puzzle before moving to the next; their execution order alternates. Sampling seeds are derived from puzzle, trial seed and prompt, so identical prompts use the same randomness in both methods. Calls are recorded/charged separately per method.

Output under `/kaggle/working/crosswords10_schema_v3/results/schema_v3_n10_exp60_seed42/` includes individual result JSON files, `results_long.csv`, `per_question.csv`, `summary.csv`, `summary.json`, raw model calls and search traces. Summary metrics include word accuracy, letter accuracy, full-puzzle solved rate, tokens, calls, runtime, expansions and invalid responses (JSON/schema/truncation failures). Summaries use only puzzles completed by both methods. Inference time excludes model load and does not represent total session runtime.

Rerun the same run cell to resume. Completed methods are skipped and successful calls are replayed with their original costs. Source, model/runtime, dataset and config changes require a fresh output directory. Download the final ZIP/checkpoint using the export cell. To recover after a Kaggle reset, attach your own ZIP to a new session and extract it under `/kaggle/working` before setup. Use the same package versions and GPU/runtime for an exact resume; the notebook saves `pip_freeze.txt`. After a hard crash, remove a stale `run.lock` only when no benchmark is active. A call interrupted before its response is saved has unknown cost; for cost comparisons, start a fresh trial rather than silently ignoring interrupted GPU work.

Sources: https://github.com/princeton-nlp/tree-of-thought-llm and https://github.com/princeton-nlp/tree-of-thought-llm/blob/master/scripts/crosswords/search_crosswords-dfs.ipynb
